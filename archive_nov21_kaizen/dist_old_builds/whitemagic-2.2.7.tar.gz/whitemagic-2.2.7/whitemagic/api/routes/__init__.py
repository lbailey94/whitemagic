"""WhiteMagic API Routes."""

from . import dashboard, api_keys

__all__ = ["dashboard", "api_keys"]
