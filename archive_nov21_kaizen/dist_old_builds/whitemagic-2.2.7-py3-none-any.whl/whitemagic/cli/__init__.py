"""CLI commands for WhiteMagic."""
__version__ = "0.1.0"
