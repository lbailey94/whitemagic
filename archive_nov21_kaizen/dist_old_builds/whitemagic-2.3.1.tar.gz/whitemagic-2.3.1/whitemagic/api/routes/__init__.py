"""WhiteMagic API Routes."""

from . import api_keys, dashboard

__all__ = ["dashboard", "api_keys"]
