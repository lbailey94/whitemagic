"""CLI commands for WhiteMagic."""

__version__ = "2.2.8"
